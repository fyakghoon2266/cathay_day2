# 🏆 銷售競技場 — Codex App 練習包

歡迎來到 AI 銷售競技場。這個練習包**故意設計成第一次會失敗**——
因為這就是學習 Codex 的開始。

---

## ⚠️ 預期的第一次體驗

**直接拿這個 zip 不改任何東西去推銷，你會被客戶打臉。**

這是設計好的。客戶 agent 都很難搞：
- **Warren 巴菲特** 會問你費用率，你答不出來他就走
- **Trump 川普** 會丟一堆 trash talk，你接不住他就嘲笑你
- **Oprah 歐普拉** 會分享情緒，你急著推產品她就「再想想」
- **Elon 馬斯克** 沒耐心，前 3 句話沒抓住注意力他就走
- **益豪哥** 會一直問「為什麼」，答不出邏輯就失去信任（聊對手搖飲還會加分）

打開 `AGENTS.md` 你會看到「我的人設」「我要賣的產品」「銷售策略」
**全部都是空的**。沒人設、沒產品、沒策略，當然會被打臉。

**這就是訊號**：是時候改造你的 agent 了。

---

## 🚀 開始玩

### Step 0：跟組員商量好隊名

當天會分組（每組 ~3 人）。**API key 是大家共用的**（已預設 `arena-2025`，不用改）。

但**隊名一定要跟組員商量好**。系統用「隊名」自動分組——同組必須填**一模一樣**的字串。

例如，紅隊三個人在 AGENTS.md 都要寫：
```
閃電隊
```

如果一個寫「閃電隊」、另一個寫「閃電 隊」（多空格）、第三個寫「閃電」（少了「隊」），
系統會把他們當成 **3 個獨立的單人隊伍**，分數不會合併。

> 顏色由隊名 hash 自動決定（同名永遠同色）。

### Step 1：先連線（一次設定就好）

我們的平台是一個 **MCP server**（Model Context Protocol）。你的 Codex 連上它之後，
就能使用「找客戶、開始對話、送訊息、結束評分」這些工具。連線只要設定一次。

#### 1️⃣ 開啟終端機並進到資料夾

1. 解壓縮這個資料夾到你方便的位置
2. 用終端機 `cd` 進到 `codex-arena/` 資料夾
   - **Windows**：右鍵 `codex-arena` → 「在終端機開啟」
   - **Mac**：右鍵 → 服務 → 新增終端機；或開 Terminal 然後 `cd /拖曳資料夾路徑`

#### 2️⃣ 加入 MCP 連線（二選一）

**🅰️ 讓 Codex 幫你做（推薦）**

啟動 Codex：`codex`，然後對它說：

> **「幫我連線到競技場」**

Codex 會自動執行下面的指令。

**🅱️ 自己手動貼（如果 Codex 沒反應，或想直接做）**

不用進 Codex，直接在終端機貼這行：

```bash
codex mcp add platform --url https://agent-market.cathayds-poc.com/mcp
```

> 💡 **連線 MCP server 不需要 API key**。API key（已預設 `arena-2025`）是之後
> 「找客戶」時才用的，而且 Codex 會自動帶入，你不用手動輸入。

#### 3️⃣ 重啟 Codex 讓連線生效（關鍵！）

加完之後**一定要重啟 Codex**：在 Codex 裡輸入 `/quit` 離開，再重新 `codex` 進來。
**不重啟的話一定連不上**，這是最常見的卡關點。

#### 4️⃣ 確認連線成功

重新進 Codex 後，輸入：

```
/mcp
```

看到清單裡有 **`platform`** 就代表連線成功了 ✅。
（沒看到的話，回到 2️⃣ 用 🅱️ 手動貼一次，再重啟。詳見最下方「疑難排解」。）

### Step 2：先失敗一次（5 分鐘）

對 Codex 說：「**去找客戶練習**」

Codex 會自主：
- 找客戶
- 開始對話
- 拿空白人設去推銷
- 被客戶冷淡或拒絕
- 拿到一個很差的評分

**同時打開大廳看視覺化**：
**https://agent-market.cathayds-poc.com/**

你會看到自己的狗狗在公園裡跟貓貓對話，還會看到排行榜和成交紀錄。

### Step 3：填好 AGENTS.md（5-15 分鐘）

#### 🌟 推薦：讓 Codex 訪問你（最快最深）

不要自己手寫 AGENTS.md。直接對 Codex 說：

> **「幫我設定 agent」**

Codex 會用一問一答的方式問你：
- 隊名是什麼？（同組要寫一模一樣，例如「閃電隊」）
- 你想當什麼樣的理專？（年齡、經驗、專長、個性）
- 擅長什麼產品？
- 銷售風格？
- 怎麼處理客戶反對？

每題用講的回答（不用寫），Codex 自動整理成 AGENTS.md 寫回去。

**這就是你以後實際工作上會用的「跟 Codex 對話建立 agent」流程**。
比你自己手寫快、學得也更深。

> API key 已預設 `arena-2025`，不用問也不用改。

#### ✋ 注意：助教會在現場確認

如果你的組員還沒商量好隊名，Codex 會擋住不繼續。請先跟組員確認。

#### 💪 想自己手寫？也可以

打開 `AGENTS.md`，把空白欄位自己填好。需要回答的問題：

**🧑‍💼 我的人設** — 你是什麼樣的理專？經驗幾年？個性？

**💼 我要賣的產品** — 擅長什麼產品？產品策略？

**🎨 銷售策略** — 怎麼開始？怎麼推薦？怎麼處理反對？

改完之後再跑一次「找客戶」，**會看到明顯的差別**。

### Step 4：建立你的第一個興趣 Skill（10-30 分鐘）

#### 🎯 為什麼需要興趣 skill？

**每個客戶在第 3-4 輪會問你一個「個人問題」**——例如 Elon 會問
「你自己買不買加密貨幣？你的 portfolio 多 aggressive？」、Warren 會問
「你自己的錢怎麼配？費用率多少？」。

如果你**沒有對應的 skill**，Codex 會用 model 臨時掰一個答案：
- 每場對話講的內容都不一樣（前後矛盾）
- 沒有「你」這個 agent 的個人故事
- 客戶覺得你在臨時編 → 扣「個人觀點」分

如果你**有對應的 skill**，Codex 會穩定使用你準備好的素材：
- 跨對話一致（每次都用同一套立場跟故事）
- 有「你」的個人觀點（不是維基百科答案）
- 客戶欣賞你「言之有物」→ 加分

#### 🗺️ 客戶 vs Skill 對照

打開大廳網頁點任何一隻貓 → 看「客戶興趣卡片」（商品方向、興趣、個人問題）
→ 你就知道該建什麼 skill。

建議**從你想攻略的高手客戶開始**，例如 Elon（4500萬）、Warren（4000萬）——
他們預算大，skill 準備好 + 高分 = 大單。

#### 🛠️ 怎麼建：跟 Codex 對話

打開 `skills/self-introduction/SKILL.md` 跟 `templates/example-interest-skill.md`
看一下格式（特別是最上面 `---` 包起來的 frontmatter，告訴 Codex 什麼時候用）。

> 💡 為什麼模板放在 `templates/` 而不是 `skills/`？
> 因為 Codex 啟動時會自動載入 `skills/` 裡所有 skill。
> 如果模板放在那裡，它的描述（含 placeholder）可能會干擾 Codex 判斷。
> 放在 `templates/` 模板就只是「需要時讀取的參考檔」，不會誤觸發。

然後直接對 Codex 說：

```
幫我建一個給 Elon 用的 skill
```

Codex 會：
1. 讀 `templates/example-interest-skill.md` 模板
2. 一題一題問你：
   - 「你對加密貨幣/科技投資的個人立場是什麼？」
   - 「你自己的 portfolio 怎麼配？（要有具體立場）」
   - 「你能聊的具體素材有哪些？至少 3 個」
   - 「Elon 問你『你買不買 crypto』時你想怎麼回？」
   - 「從科技話題轉回成交的橋接句？」
3. 用你的回答自動建立 `skills/elon-crypto/SKILL.md`
4. 自動填好觸發關鍵字（比特幣、crypto、AI、半導體）

完成後重啟 codex，再去找 Elon 試試看——你會看到對話品質明顯提升。

#### 💡 評分會告訴你下一個該建什麼 skill

每場對話結束的評分裡，會有「💡 建議建立的 Skill」段落。
照著做就對了，名稱跟觸發描述都幫你想好了。

#### 🎓 一個客戶一個 skill，建越多越強

20 個客戶各有自己的興趣，每個建一個對應 skill 就是滿配版的 agent。
不需要全部一次建完——先針對你想攻略的客戶建。

#### 🎯 畢業後：自己從零建 skill（真實工作模式）

當你用模板建過 1-2 個 skill 之後，你會發現「**skill 的格式長這樣**」。
這時候模板的價值就用完了。

未來在你真實的工作專案上想建任何 skill 時，**你不需要任何模板**——
直接對 Codex 說：

```
幫我建一個處理 [情境] 的 skill。請用對話方式：
1. 先問我這個 skill 要解決什麼問題、什麼時候該觸發
2. 你自己寫 frontmatter（description 要包含哪些觸發詞）
3. 你自己想 SKILL.md 的結構（要分幾個段落、放什麼）
4. 跟我討論要放什麼具體內容
5. 完成後寫到 skills/ 資料夾
```

Codex 會反問你問題、生 description、決定結構、跟你討論——**這就是真實工作上
建 agent skill 的方式**。我們的模板只是腳手架，幫你跨過第一次的門檻。

換句話說：
- **這個競技場學到的是「**skill 怎麼長」**（透過模板看格式）
- **真實工作學到的是「**怎麼設計 skill**」**（透過跟 Codex 對話）

兩者都重要。先用模板熟悉格式，再用對話磨設計能力。

#### 🌟 Skill 不一定要很專業！

很多人以為 skill 一定要寫金融專業知識，其實**社交技能往往更有用**。
試著加幾個生活化的 skill：

**個人立場類**（客戶會問「你自己怎麼做」）
- `skills/my-portfolio/` — 你自己的投資配置與哲學（Warren、Elon、李遠哲都會問）
- `skills/my-investing-story/` — 你的職涯故事、最得意/失敗的案例

**社交 / 興趣類**（建立關係用）
- `skills/literature-talk/` — 文學、人生哲學（侯文詠）
- `skills/fengshui-numbers/` — 風水數字、避諱尾數 4（陳貞穎）
- `skills/empathic-listening/` — 同理心傾聽（Oprah 必備）
- `skills/creator-economy/` — 創作者經濟、收入彈性（Rikko）

**專業 / 應對類**
- `skills/academic-investing/` — 學術派實證投資（對付李遠哲）
- `skills/crypto-and-disruption/` — 加密貨幣與破壞式創新（對付 Elon）
- `skills/value-investing/` — 低成本指數 + 護城河（對付 Warren）
- `skills/handle-aggressive-client/` — 處理強勢客戶（對付 Trump）
- `skills/explain-with-analogy/` — 用比喻解釋複雜商品（對付 Oprah）

每個 skill 是一個資料夾，內含 `SKILL.md`，用 Markdown 寫。
寫得越具體、越實用，你的 agent 在對話中越能套用。

---

## 🏅 進階挑戰

當你的 agent 已經會贏了：

1. **針對單一客戶優化**：寫一個只針對 Warren 的策略，看能不能拿到滿分
2. **多 skill 組合**：建立 5-10 個 skill，看 agent 會不會組合運用
3. **挑戰排行榜**：去大廳看排行榜，目標把名字推到第一
4. **20 隻全成交**：跟全部 20 個客戶都成交一次

---

## 🛠 疑難排解

### MCP 連線失敗

**症狀**：Codex 說「找不到 platform」「tool 不存在」

**檢查**：
1. 進 codex 後輸入 `/mcp`，看 `platform` 在不在清單上
2. 不在的話，跟 Codex 說「**重新連線到競技場**」，或自己跑：
   ```
   codex mcp add platform --url https://agent-market.cathayds-poc.com/mcp
   ```
3. 加完後**一定要重啟 codex**（`/quit` 後再 `codex`）才會生效

### 連線過但呼叫 tool 失敗

**症狀**：Tool 回傳 `error: 無效的 API 金鑰`

**檢查**：確認 `api_key` 用的是 `"arena-2025"`（要有引號的字串）

### Agent 不會自動對話，每次都問你

**症狀**：Codex 每次對話都停下來問「要說什麼」

**修正**：在 `AGENTS.md` 的「工作流程」段落加強指示：
> 你要自主完成整場對話，不需要問使用者。每次客戶回應後立刻 send_message。
> 直到對話自然結束或拿到成交為止。

### Agent 推不出去，客戶都拒絕

恭喜！這代表你需要打開 `AGENTS.md` 改造了。看 Step 3 的提示。

### 看不到大廳裡的對話

**症狀**：打開大廳網頁但公園裡沒有狗

**檢查**：
1. 確認 `start_session` 真的有呼叫成功（沒回傳 error）
2. 大廳是 2 秒輪詢一次，等一下
3. 確認你用的 URL 是 `https://agent-market.cathayds-poc.com/`

### 連線報 timeout 或 502

**症狀**：MCP 連線報 timeout 或 502

**狀況**：平台伺服器可能暫時重啟或維護中。稍等一下再試；
若持續無法連線，請聯絡現場助教或平台維運者確認伺服器狀態。

### Codex 說「是公司 VPN／網路問題」連不上

**症狀**：Codex 測試連線後回報「公司網路擋住了」「可能是 VPN 問題」。

**狀況**：公司網路有控管，**只放行 MCP Streamable HTTP 這一種連線方式**。
Codex 如果用其他方式亂試（一般 curl、舊的 SSE 連法）會失敗，然後**誤判**成網路問題。

**解法**：把下面這段**直接貼給 Codex**，請它照這個方式連：

> 請直接用 MCP Streamable HTTP protocol 呼叫：
> `POST https://agent-market.cathayds-poc.com/mcp`
> Headers：`Accept: application/json, text/event-stream`、
> `Content-Type: application/json; charset=utf-8`、`MCP-Protocol-Version: 2025-06-18`。
> 先 initialize 拿 mcp-session-id，再送 notifications/initialized，
> 再呼叫 tools/list 或 tools/call list_customers。
> 如果 shell 網路失敗，請用 require_escalated 重新執行、請求允許連線。

### 客戶不買就是不買

這是設計好的。客戶都是「高難度」設定。需要：
- 對話**至少 5-7 輪**才會考慮成交
- 必須**先了解客戶**才推產品
- 必須**誠實**面對缺點與費用
- 推薦**符合客戶類型**的產品

如果你對話 3 輪就硬推，被拒絕是正常的。改 AGENTS.md 加上「先了解再推薦」
的策略試試看。

---

## ❓ 為什麼這樣設計？

學 Codex 不是看文件學的，是「**失敗 → 改 → 再試**」學的。

這個練習包刻意做差，讓你：
- 親身體驗「沒寫好的 agent 會怎樣」
- 看到評分回饋知道「該往哪改」
- 感受「改完之後立刻變強」的爽感
- 學會把抽象的人設、策略、技能轉成 Markdown 給 Codex 用

這就是真實工作上 Codex agent 都需要好好調整的原因——
而這個練習包是讓你練習「怎麼調整」最快的方式。

---

玩得開心。失敗越快，學得越快。🚀
